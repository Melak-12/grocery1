import 'package:flutter/material.dart';

class CartMode extends ChangeNotifier {
  int _size = 0;
  int get size => _size;
}
